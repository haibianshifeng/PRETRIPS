#!/bin/bash
echo '3DPRE to calculate reactive flow in 3D'
command export OMP_NUM_THREADS="8"
gfortran  -mcmodel=medium  -fopenmp 3DPRE.f90 -o 3DPRE
echo 'Porgram compiled'
echo 'Program running'
./3DPRE
echo 'Program finished'

