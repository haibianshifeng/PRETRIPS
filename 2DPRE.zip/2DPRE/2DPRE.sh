#!/bin/bash
echo '2DPRE to calculate flow in 2D'
gfortran -mcmodel=medium 2DPRE.f90 -o 2DPRE
echo 'Porgram compiled'
echo 'Program running'
./2DPRE
echo 'Program finished'

