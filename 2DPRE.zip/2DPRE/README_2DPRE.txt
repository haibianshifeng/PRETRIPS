2DPRE is used to solve the reactrion between two different fluids on 2D images of porous media.

This code is wirrten with Fortran 90. To run this code, just open a terminal and just put the command "./2DPRE.sh". 
Users can find an example of simulation in the 'Example' folder.

