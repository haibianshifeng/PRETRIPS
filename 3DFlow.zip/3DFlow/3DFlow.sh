#!/bin/bash
echo '3DFlow to calculate flow in 3D'
gfortran -mcmodel=medium 3DFlow.f90 -o 3DFlow
echo 'Porgram compiled'
echo 'Program running'
./3DFlow
echo 'Program finished'

