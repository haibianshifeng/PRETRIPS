3DFlow is used to calculate velocity on 3D images of porous media based on Lattice Boltzmann Mthod with D3Q19 scheme.

This code is wirrten with Fortran 90. To run this code, just open a terminal and just put the command "./3DFlow.sh". 
Users can find an example of simulation in the 'Example' folder.

