#!/bin/bash
echo '2DFlow to calculate flow in 2D'
gfortran 2DFlow.f90 -o 2DFlow
echo 'Porgram compiled'
echo 'Program running'
./2DFlow
echo 'Program finished'
