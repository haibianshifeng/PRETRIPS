#!/bin/bash
echo '3DFlow to calculate flow in 3D'
gfortran -mcmodel=medium bead-PREmix.f90 -o PREmix
echo 'Porgram compiled'
echo 'Program running'
./PREmix
echo 'Program finished'

