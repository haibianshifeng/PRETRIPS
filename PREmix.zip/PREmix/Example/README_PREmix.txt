This is an example of fluid/fluid reaction in beadpack. Before simulation, unzip the files first. The velocity data can be downloaded from 'https://drive.google.com/open?id=0B-R2XWTOej3hVDVtQkswWTB6Y2c'.

PREmix is used to solve the reactrion between two different fluids on 3D images of porous media.

This code is wirrten with Fortran 90. To run this code, just open a terminal and just put the command "./PREmix.sh". 
Users can find an example of simulation in the 'Example' folder.

